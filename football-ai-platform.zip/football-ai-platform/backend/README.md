# Backend

API, data models (player profile, film, evaluations, drills, plans, progress), and the
film analysis / comparison pipeline.

## Planned modules (map to roadmap phases)

- `players/` — player profile model + CRUD (Phase 1)
- `film/` — upload, storage, metadata (Phase 2)
- `analysis/` — position-specific breakdown pipeline (Phase 3)
- `reports/` — strengths/weaknesses generation + priority tiers (Phase 4)
- `comparisons/` — pro-player style similarity + elite benchmarks (Phases 5–6)
- `drills/` — drill generator + routine/weekly plan builder (Phases 7–9)
- `progress/` — tracking + trend reporting, re-evaluation loop (Phases 10–11)

Not yet scaffolded — stack TBD.
