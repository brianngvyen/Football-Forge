# MVP (v0.1)

Enough to demonstrate the core idea, without building all 15 phases:

1. Player profile
2. Film upload
3. Position-specific analysis
4. Strengths & weaknesses
5. Pro-style comparison
6. Personalized drills
7. Weekly training plan
8. Re-upload film
9. Progress report

## Suggested build order

- [ ] Player profile model + form (Phase 1)
- [ ] Film upload + storage (Phase 2)
- [ ] Position-specific analysis pipeline — start with one position (e.g. WR) (Phase 3)
- [ ] Strengths/weaknesses report generation + priority tiers (Phase 4)
- [ ] Pro-player comparison (start with a small hand-picked reference set) (Phase 5)
- [ ] Drill generator mapped to weakness categories (Phase 7)
- [ ] Weekly plan generator (Phase 9)
- [ ] Re-upload flow + before/after comparison (Phase 11)
- [ ] Progress report / skill trend view (Phase 10)

## Open questions

- Tech stack (web app? mobile? which AI/vision approach for Phase 3+?)
- How film analysis actually happens in the MVP — manual/human-in-the-loop scoring
  vs. automated computer vision (full CV is Phase 14, likely out of scope for v0.1)
- Which position to support first
- Where the "pro player" reference data/comparisons come from
