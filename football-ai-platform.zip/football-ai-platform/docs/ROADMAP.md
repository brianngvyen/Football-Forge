# Roadmap

The differentiator isn't "AI evaluates football film" — it's the closed loop:

```
WATCH YOU → UNDERSTAND YOU → COMPARE YOU → IDENTIFY THE GAP →
PRESCRIBE TRAINING → TRACK IT → WATCH YOU AGAIN
```

## Phase 1 — Player Profile
Name, age, position (primary/secondary), height/weight, level (youth/HS/college/semi-pro),
goals, current team, and optional athletic testing (40-yard dash, vertical, broad jump,
shuttle, bench, position-specific tests). Gives the AI context before it looks at film.

## Phase 2 — Film Upload
- **Highlight film** — shows what a player does well, playmaking, athletic traits.
- **Full-game film** — much more valuable: missed opportunities, bad decisions,
  inconsistent technique, off-ball plays, effort, discipline.
- **Practice film** — technique, repetition, drills, consistency.

Long-term goal: encourage full-game + highlight film, not just highlights.

## Phase 3 — AI Film Breakdown
Identify the player's position and analyze individual plays. Example (WR):
- **Technical** — releases, route running, breaks, hands, catch point, blocking, footwork
- **Physical** — burst, acceleration, change of direction, contact balance, play strength
- **Mental** — coverage recognition, leverage awareness, zone/situational awareness
- **Production** — targets, receptions, yards, YAC, explosive plays, drops

Observations attach to specific plays/clips, not vague claims.

## Phase 4 — Strengths & Weaknesses
Personalized report (strengths / development areas), with weaknesses prioritized:
- **Priority 1** — major development area
- **Priority 2** — important improvement
- **Priority 3** — fine-tuning

## Phase 5 — Pro Player Style Comparison
Not "you're the next X" — instead: "your current style shares characteristics with
[Player A: 74%], [Player B: 68%], [Player C: 63%]," broken down across athletic
profile, technical profile, play style, and football IQ, with explicit gaps called out
("you resemble Player A in X, but your technique currently differs in Y").

## Phase 6 — Elite Benchmark
Compare the player's current skill ratings against an elite benchmark per skill
(e.g. Release: 6.5 → 9.0, Route running: 7.0 → 9.5) to give a concrete destination.

## Phase 7 — Personalized Drill Generator
Turn weaknesses into specific drills with sets/reps and focus cues, plus targeted
film study (e.g. study elite releases, identify DB leverage, predict the right release).

## Phase 8 — Daily Football Routine
Turn drills into a daily schedule: morning (footwork/mechanics/mobility), field session
(releases/route breaks/contested catches/YAC), film review, and a night log
(completed, difficulty, notes).

## Phase 9 — Weekly Development Plan
A weekly objective broken into a day-by-day plan, adjusted based on performance.

## Phase 10 — Progress Tracking
Track drills completed, training volume, film watched, testing numbers, coach
feedback, self-evaluation, and new game film. Show skill trends over time
(e.g. Release: 6.5 → 7.0 → 7.6 → 8.1).

## Phase 11 — Re-Upload & Re-Evaluation
The core product loop: analyze film → train → new film → re-analyze → compare →
identify remaining weaknesses → new drills → repeat.

## Phase 12 — Coach Mode
Coaches review player reports, add their own evaluations, assign drills, track
multiple players, compare development, leave notes, and upload practice film.
The AI assists the coach rather than replacing them.

## Phase 13 — Recruiting Profile
A shareable player development profile (position, class, measurables, strengths,
development areas, highlight + full-game film, trajectory) for HS players to send
to coaches.

## Phase 14 — Advanced AI
- **Computer vision** — detect player movement, routes, alignment, tackles, blocks,
  releases, coverage.
- **Football intelligence** — understand formation, coverage, defensive alignment,
  route concepts, leverage, assignments.
- **Player modeling** — a numerical representation of athleticism + technique +
  football IQ + style, compared against pro/college players.

## Phase 15 — "Path to Elite"
The ultimate feature: current level, primary weaknesses, a 90-day objective, and a
month-by-month plan — with the AI verifying whether skills actually transferred to
games after new film is uploaded.

---

See [`MVP.md`](MVP.md) for what ships first.
