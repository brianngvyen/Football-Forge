# Frontend

Player-facing app: profile creation, film upload, viewing reports (strengths/weaknesses,
pro comparisons, drills, weekly plans, progress over time).

Not yet scaffolded — stack TBD.
